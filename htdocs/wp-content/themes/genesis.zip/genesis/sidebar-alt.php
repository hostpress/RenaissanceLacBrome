<div id="sidebar-alt" class="widget-area">
<?php
	genesis_before_sidebar_alt_widget_area();
	genesis_sidebar_alt();
	genesis_after_sidebar_alt_widget_area();
?>
</div>