<div id="sidebar" class="widget-area">
<?php
	genesis_before_sidebar_widget_area();
	genesis_sidebar();
	genesis_after_sidebar_widget_area();
?>
</div>