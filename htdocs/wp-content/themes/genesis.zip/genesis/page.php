<?php
/**
 * This file handles pages, but only exists for the sake of
 * child theme forward compatibility.
 */
genesis();