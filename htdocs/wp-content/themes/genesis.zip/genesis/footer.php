</div><!-- end #inner -->
<?php
	genesis_before_footer();
	genesis_footer();
	genesis_after_footer();
?>
</div><!-- end #wrap -->
<?php
	wp_footer(); // we need this for plugins
	genesis_after();
?>
</body>
</html>