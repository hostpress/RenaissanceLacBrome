<?php
/**
 * Template Name: Blog
 * This file handles blog post listings within a page.
 */
genesis();